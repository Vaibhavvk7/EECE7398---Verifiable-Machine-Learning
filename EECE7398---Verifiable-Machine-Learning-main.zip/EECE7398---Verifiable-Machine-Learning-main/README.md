# EECE7398---Verifiable-Machine-Learning
Contains projects and assignments for EECE7398 - Verifiable Machine Learning, Fall 2024, Professor Michael Everett, Northeastern University Boston
